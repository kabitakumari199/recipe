import React, { Component } from 'react';
import Routing from './routes';

 function App()  {
 
    return (
    <React.Fragment>
      <Routing />
    </React.Fragment>
    )
  }

export default App;